/**
 *
 * Descripcion: Implementacion de funciones de ordenacion 
 *
 * Fichero: ordenacion.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */


#include "ordenacion.h"

/***************************************************/
/* Funcion: InsertSort    Fecha:                   */
/* Vuestro comentario                              */
/***************************************************/
int InsertSort(int* tabla, int ip, int iu)
{
  /* vuestro codigo */
}

/***************************************************/
/* Funcion: InsertSortInv    Fecha:                   */
/* Vuestro comentario                              */
/***************************************************/
int InsertSortInv(int* tabla, int ip, int iu)
{
  /* vuestro codigo */
}

